import { Component, OnInit } from '@angular/core';
import { forkJoin } from 'rxjs';
import { map, mergeMap } from 'rxjs/operators';
import { AppService } from './app.service';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  random10Dogs = [];
  randomImage: string;

  constructor(private appService: AppService) {}

  ngOnInit() {
    this.appService
      .getDogs()
      .pipe(
        mergeMap((dogs: any) =>
          this.appService.getDogImage(this.getRandomDog(dogs.message)).pipe(
            map((res) => ({
              dogs: dogs.message,
              dogImage: res.message,
            }))
          )
        )
      )
      .subscribe((res) => {
        this.randomImage = res.dogImage;
        this.get10RandomDogs(res.dogs);
      });
  }

  get10RandomDogs(dogs) {
    const random10DogsAPIs = [];
    for (let i = 0; i < 10; i++) {
      random10DogsAPIs.push(
        this.appService.getDogImage(this.getRandomDog(dogs))
      );
    }

    forkJoin(random10DogsAPIs).subscribe((res) => {
      this.random10Dogs = res.map((i) => i.message);
    });
  }

  private getRandomDog(allDogs) {
    const keys = Object.keys(allDogs);
    const randomKey = keys[Math.floor(Math.random() * keys.length)];

    return allDogs[randomKey].length > 0
      ? `${randomKey}/${allDogs[randomKey][0]}`
      : randomKey;
  }
}
